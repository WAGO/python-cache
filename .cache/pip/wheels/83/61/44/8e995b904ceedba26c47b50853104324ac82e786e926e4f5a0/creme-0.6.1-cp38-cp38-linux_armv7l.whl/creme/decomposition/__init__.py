"""Matrix decomposition."""
from .lda import LDA


__all__ = [
    'LDA',
]
